package com.eviro.assessment.grad001.khensanisemenya;
import java.math.BigDecimal;

public class Main {
   
   private static SystemDB obj;
     
   public static void main(String[] args)  
    { 
       obj =SystemDB.getInstance();
        
       obj.populateDatabase();
       
       // Withdraw R800 from Savings Account 1
       obj.savingsAccount.get("1").withdraw("1", BigDecimal.valueOf(800));
       
       // Withdraw R500 from Savings Account 1 again
       obj.savingsAccount.get("1").withdraw("1", BigDecimal.valueOf(500));
       
       
       // Withdraw R9000 from Current Account 3
       obj.currentAccount.get("3").withdraw("3", BigDecimal.valueOf(9000));
       
       // Withdraw R1000 from Current Account 3 again
       obj.currentAccount.get("3").withdraw("3", BigDecimal.valueOf(1000));
       
       // Withdraw R500 from Current Account 3 again
       obj.currentAccount.get("3").withdraw("3", BigDecimal.valueOf(500));
       
       // Withdraw R600 from Current Account 3 again
       obj.currentAccount.get("3").withdraw("3", BigDecimal.valueOf(600));
    } 
}
