/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eviro.assessment.grad001.khensanisemenya;
import java.io.IOException;
import java.math.BigDecimal;  
import java.util.logging.Level;
import java.util.logging.Logger;
class SavingsAccount implements AccountService{
    private String customerNum;
    private int id;
    private String accountNum;
    private BigDecimal balance;
    
    public String getAccountNum()
    {
        return accountNum;
    }
    public BigDecimal getBalance()
    {
        return balance;
    }
    public void updateBalance(BigDecimal _balance)
    {
         balance=_balance;
    }
     
    public SavingsAccount(String _customerNum,int _id,String _accountNum,BigDecimal _balance)
    {
      customerNum=_customerNum;
      id=_id;
      accountNum=_accountNum;
      balance=_balance; 
    }

    @Override
    public void withdraw(String _accountNum, BigDecimal amountToWithdraw)  
    {
        try { 
            
            if(_accountNum.equals(accountNum))
            {
                if(balance.doubleValue()-amountToWithdraw.doubleValue()>1000.00)
                {
                 //  balance=balance.subtract(amountToWithdraw);
                   updateBalance( balance.subtract(amountToWithdraw) );
                   System.out.println("Savings Account "+_accountNum+", Successfully Withdraw R"+amountToWithdraw.toString()+" | BALANCE R"+getBalance().toString());
                }
                else
                {
                    
                    throw new WithdrawalAmountTooLargeException("Savings Account "+_accountNum+", Failed to Withdraw R"+amountToWithdraw.toString()+" , Balance will be less than MINIMUM BALANCE of R1000");
                } 
            }
            else
            {
                System.out.println("Account number not found"); 
            }
            
            
        }
        catch (WithdrawalAmountTooLargeException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
}
