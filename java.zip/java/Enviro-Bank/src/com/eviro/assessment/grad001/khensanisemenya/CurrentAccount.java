/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eviro.assessment.grad001.khensanisemenya;

import java.math.BigDecimal;
import java.util.logging.Level;
import java.util.logging.Logger;
class CurrentAccount extends SavingsAccount implements AccountService {
    private BigDecimal overdraft;

    public CurrentAccount(String _customerNum, int _id, String _accountNum, BigDecimal _balance,BigDecimal _overdraft) 
    {
        super(_customerNum, _id, _accountNum, _balance);
        overdraft=_overdraft;
    }   

    @Override
    public void withdraw(String _accountNum, BigDecimal amountToWithdraw) 
    {
       try { 
            
            if(_accountNum.equals(super.getAccountNum()))
            {
                if(amountToWithdraw.doubleValue()<= super.getBalance().add(overdraft).doubleValue())
                {
                   super.updateBalance(super.getBalance().subtract(amountToWithdraw));
                   System.out.println("Current Account "+_accountNum+", Successfully Withdraw R"+amountToWithdraw.toString()+" | BALANCE R"+super.getBalance().toString());
                }
                else
                {
                    
                    throw new WithdrawalAmountTooLargeException("Current Account "+_accountNum+", Failed to Withdraw R"+amountToWithdraw.toString()+" , Requested amount is more than (Balance + overdraft limit)");
                } 
            }
            else
            {
                System.out.println("Account number not found"); 
            }
            
            
        }
        catch (WithdrawalAmountTooLargeException ex) 
        {
            System.out.println(ex.getMessage());
        }
    }
}
